import java.util.ArrayList;

public class Regression {
    public static void main(String[] args) {
        //defining arrays
        ArrayList<Double> xValues = new ArrayList<>();
        ArrayList<Double> yValues = new ArrayList<>();
        xValues.add(225.0); yValues.add(12000.0);
        xValues.add(240.0); yValues.add(12445.0);
        xValues.add(245.0); yValues.add(12556.0);
        xValues.add(250.0); yValues.add(12500.0);
        xValues.add(275.0); yValues.add(12787.0);
        xValues.add(280.0); yValues.add(12856.0);
        xValues.add(280.0); yValues.add(13010.0);
        xValues.add(290.0); yValues.add(13020.0);
        double[] coeffs = linearRegression(xValues, yValues);
        System.out.println("Predicted Sales for 2024: " + coeffs[0]);
    }

    public static double[] linearRegression(ArrayList<Double> xValues, ArrayList<Double> yValues) {
        int n = xValues.size();
        double xSum = 0.0, ySum = 0.0, xySum = 0.0, xSqSum = 0.0;
        for (int i = 0; i < n; i++) {
            xSum += xValues.get(i);
            ySum += yValues.get(i);
            xySum += xValues.get(i) * yValues.get(i);
            xSqSum += xValues.get(i) * xValues.get(i);
        }
        double xMean = xSum / n;
        double yMean = ySum / n;
        double slope = (xySum - n * xMean * yMean) / (xSqSum - n * xMean * xMean);
        double intercept = yMean - slope * xMean;
        double[] coeffs = {intercept, slope};
        return coeffs;
    }

}
